export default {
  expo: {
    name: "Jewbal Monkey Chaos",
    slug: "jewbal-monkey-chaos",
    version: "1.0.0",
    orientation: "portrait",
    assetBundlePatterns: ["**/*"],
  },
};
