import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Dimensions } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';

/**
 * Jewbal Monkey Chaos - HTML5 Game Component
 * 
 * A hybrid arcade game combining monkey-throwing mechanics with Auralia jewbal aesthetics.
 * Rendered via WebView or embedded canvas for mobile.
 */

const GameScreen = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState('menu'); // menu, playing, gameover

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Game configuration
    const config = {
      width: canvas.width,
      height: canvas.height,
      gravity: 0.5,
      friction: 0.98,
    };

    // Game state
    let game = {
      score: 0,
      level: 1,
      lives: 3,
      running: false,
      paused: false,
      combo: 0,
      comboTimer: 0,
    };

    // Player (jewbal character)
    const player = {
      x: config.width / 2 - 20,
      y: config.height - 60,
      width: 40,
      height: 40,
      vx: 0,
      vy: 0,
      speed: 5,
      throwCooldown: 0,
      throwRate: 8,
    };

    // Arrays for game objects
    let enemies: any[] = [];
    let projectiles: any[] = [];
    let particles: any[] = [];
    let powerups: any[] = [];

    // Input handling
    const keys: { [key: string]: boolean } = {};

    const handleKeyDown = (e: KeyboardEvent) => {
      keys[e.key.toLowerCase()] = true;
      if (e.key === ' ') {
        e.preventDefault();
        throwProjectile();
      }
      if (e.key === 'p' || e.key === 'P') {
        game.paused = !game.paused;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keys[e.key.toLowerCase()] = false;
    };

    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);

    // Game functions
    const throwProjectile = () => {
      if (player.throwCooldown <= 0 && game.running) {
        projectiles.push({
          x: player.x + player.width / 2,
          y: player.y,
          vx: 0,
          vy: -8,
          width: 8,
          height: 8,
          life: 300,
          damage: 1,
        });
        player.throwCooldown = player.throwRate;
      }
    };

    const spawnEnemy = () => {
      const types = ['blob', 'spike', 'weaver'];
      const type = types[Math.floor(Math.random() * types.length)];
      const x = Math.random() * (config.width - 30);
      
      enemies.push({
        x,
        y: -30,
        width: 30,
        height: 30,
        vy: 1 + game.level * 0.3,
        vx: (Math.random() - 0.5) * 2,
        type,
        health: type === 'spike' ? 2 : 1,
        maxHealth: type === 'spike' ? 2 : 1,
        points: type === 'blob' ? 10 : type === 'spike' ? 25 : 50,
      });
    };

    const spawnParticles = (x: number, y: number, count: number, color: string) => {
      for (let i = 0; i < count; i++) {
        const angle = (Math.PI * 2 * i) / count;
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * 4,
          vy: Math.sin(angle) * 4,
          life: 30,
          color,
          size: 3 + Math.random() * 2,
        });
      }
    };

    const updateGame = () => {
      if (!game.running || game.paused) return;

      // Update player
      if (keys['arrowleft'] || keys['a']) player.x -= player.speed;
      if (keys['arrowright'] || keys['d']) player.x += player.speed;
      player.x = Math.max(0, Math.min(player.x, config.width - player.width));

      player.throwCooldown--;

      // Update projectiles
      for (let i = projectiles.length - 1; i >= 0; i--) {
        const p = projectiles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life--;

        if (p.y < 0 || p.life <= 0) {
          projectiles.splice(i, 1);
          continue;
        }

        // Check collision with enemies
        for (let j = enemies.length - 1; j >= 0; j--) {
          const e = enemies[j];
          if (
            p.x < e.x + e.width &&
            p.x + p.width > e.x &&
            p.y < e.y + e.height &&
            p.y + p.height > e.y
          ) {
            e.health -= p.damage;
            spawnParticles(p.x, p.y, 6, '#22D3EE');

            if (e.health <= 0) {
              game.score += e.points;
              game.combo++;
              spawnParticles(e.x + e.width / 2, e.y + e.height / 2, 12, '#7C3AED');
              enemies.splice(j, 1);
            }

            projectiles.splice(i, 1);
            break;
          }
        }
      }

      // Update enemies
      for (let i = enemies.length - 1; i >= 0; i--) {
        const e = enemies[i];
        e.x += e.vx;
        e.y += e.vy;

        // Check if enemy reached bottom
        if (e.y > config.height) {
          game.lives--;
          enemies.splice(i, 1);
          if (game.lives <= 0) {
            game.running = false;
          }
          continue;
        }

        // Check collision with player
        if (
          player.x < e.x + e.width &&
          player.x + player.width > e.x &&
          player.y < e.y + e.height &&
          player.y + player.height > e.y
        ) {
          game.lives--;
          enemies.splice(i, 1);
          if (game.lives <= 0) {
            game.running = false;
          }
        }
      }

      // Update particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.2; // gravity
        p.life--;

        if (p.life <= 0) {
          particles.splice(i, 1);
        }
      }

      // Spawn new enemies
      if (Math.random() < 0.02 + game.level * 0.005) {
        spawnEnemy();
      }

      // Update combo timer
      game.comboTimer--;
      if (game.comboTimer <= 0) {
        game.combo = 0;
      }

      // Level progression
      if (enemies.length === 0 && game.running) {
        game.level++;
      }
    };

    const drawGame = () => {
      // Clear canvas
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, config.width, config.height);

      // Draw background grid (optional)
      ctx.strokeStyle = 'rgba(34, 211, 238, 0.05)';
      ctx.lineWidth = 1;
      for (let i = 0; i < config.width; i += 40) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, config.height);
        ctx.stroke();
      }

      // Draw player
      ctx.fillStyle = '#7C3AED';
      ctx.shadowColor = '#22D3EE';
      ctx.shadowBlur = 15;
      ctx.fillRect(player.x, player.y, player.width, player.height);
      ctx.shadowBlur = 0;

      // Draw projectiles
      ctx.fillStyle = '#22D3EE';
      for (const p of projectiles) {
        ctx.shadowColor = '#22D3EE';
        ctx.shadowBlur = 8;
        ctx.fillRect(p.x, p.y, p.width, p.height);
      }
      ctx.shadowBlur = 0;

      // Draw enemies
      for (const e of enemies) {
        if (e.type === 'blob') {
          ctx.fillStyle = '#EF4444';
          ctx.shadowColor = '#FF6B6B';
        } else if (e.type === 'spike') {
          ctx.fillStyle = '#22D3EE';
          ctx.shadowColor = '#00FF88';
        } else {
          ctx.fillStyle = '#7C3AED';
          ctx.shadowColor = '#A78BFA';
        }
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(e.x + e.width / 2, e.y + e.height / 2, e.width / 2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.shadowBlur = 0;

      // Draw particles
      for (const p of particles) {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life / 30;
        ctx.fillRect(p.x, p.y, p.size, p.size);
        ctx.globalAlpha = 1;
      }

      // Draw HUD
      ctx.fillStyle = '#F1F5F9';
      ctx.font = 'bold 20px Arial';
      ctx.fillText(`Score: ${game.score}`, 10, 30);
      ctx.fillText(`Level: ${game.level}`, config.width / 2 - 50, 30);
      ctx.fillText(`Lives: ${game.lives}`, config.width - 120, 30);

      if (game.combo > 0) {
        ctx.fillStyle = '#FBBF24';
        ctx.font = 'bold 24px Arial';
        ctx.fillText(`COMBO x${game.combo}`, config.width / 2 - 80, config.height / 2);
      }

      if (game.paused) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.fillRect(0, 0, config.width, config.height);
        ctx.fillStyle = '#F1F5F9';
        ctx.font = 'bold 40px Arial';
        ctx.fillText('PAUSED', config.width / 2 - 100, config.height / 2);
      }
    };

    const gameLoop = () => {
      updateGame();
      drawGame();
      requestAnimationFrame(gameLoop);
    };

    // Start game
    const startGame = () => {
      game.running = true;
      game.score = 0;
      game.level = 1;
      game.lives = 3;
      game.combo = 0;
      enemies = [];
      projectiles = [];
      particles = [];
      player.x = config.width / 2 - 20;
      player.y = config.height - 60;
      setGameState('playing');
      gameLoop();
    };

    // Menu rendering
    const drawMenu = () => {
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, config.width, config.height);

      ctx.fillStyle = '#7C3AED';
      ctx.font = 'bold 48px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('Jewbal Monkey Chaos', config.width / 2, 100);

      ctx.fillStyle = '#22D3EE';
      ctx.font = '20px Arial';
      ctx.fillText('Tap SPACE or click to start', config.width / 2, 200);

      ctx.fillStyle = '#F1F5F9';
      ctx.font = '16px Arial';
      ctx.fillText('Arrow Keys or WASD to move', config.width / 2, 250);
      ctx.fillText('SPACE to throw projectiles', config.width / 2, 280);
      ctx.fillText('P to pause', config.width / 2, 310);
    };

    // Game over rendering
    const drawGameOver = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.fillRect(0, 0, config.width, config.height);

      ctx.fillStyle = '#EF4444';
      ctx.font = 'bold 48px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('GAME OVER', config.width / 2, 100);

      ctx.fillStyle = '#FBBF24';
      ctx.font = 'bold 36px Arial';
      ctx.fillText(`Final Score: ${game.score}`, config.width / 2, 180);

      ctx.fillStyle = '#22D3EE';
      ctx.font = '20px Arial';
      ctx.fillText('Press SPACE to play again', config.width / 2, 280);
    };

    // Initial render
    if (gameState === 'menu') {
      drawMenu();
    } else if (gameState === 'gameover') {
      drawGameOver();
    }

    // Handle canvas click to start
    const handleCanvasClick = () => {
      if (gameState === 'menu') {
        startGame();
      } else if (gameState === 'gameover') {
        setGameState('menu');
      }
    };

    canvas.addEventListener('click', handleCanvasClick);

    // Handle space key for starting
    const handleSpaceStart = (e: KeyboardEvent) => {
      if (e.key === ' ') {
        if (gameState === 'menu') {
          startGame();
        } else if (gameState === 'gameover') {
          setGameState('menu');
        }
      }
    };

    document.addEventListener('keydown', handleSpaceStart);

    // Cleanup
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('keyup', handleKeyUp);
      document.removeEventListener('keydown', handleSpaceStart);
      canvas.removeEventListener('click', handleCanvasClick);
    };
  }, [gameState]);

  const { width, height } = Dimensions.get('window');
  const canvasWidth = Math.min(width, 600);
  const canvasHeight = (canvasWidth * 4) / 3;

  return (
    <ScreenContainer className="flex-1 items-center justify-center bg-background">
      <View className="w-full items-center justify-center">
        <canvas
          ref={canvasRef}
          width={canvasWidth}
          height={canvasHeight}
          style={{
            border: '3px solid #7C3AED',
            borderRadius: 16,
            backgroundColor: '#0F172A',
            boxShadow: '0 0 30px rgba(124, 58, 237, 0.5)',
          }}
        />
      </View>
    </ScreenContainer>
  );
};

export default GameScreen;
