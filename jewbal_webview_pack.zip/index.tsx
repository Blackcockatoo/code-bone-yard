import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import GameScreen from "./GameScreen";

function Home({ navigation }: any) {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 24 }}>
      <Text style={{ fontSize: 32, fontWeight: "800", marginBottom: 12 }}>
        Jewbal Monkey Chaos
      </Text>
      <Text style={{ opacity: 0.75, textAlign: "center", marginBottom: 24 }}>
        Throw bananas. Dodge doom. Become legend.
      </Text>

      <TouchableOpacity
        onPress={() => navigation.navigate("Game")}
        style={{
          backgroundColor: "#111",
          paddingHorizontal: 22,
          paddingVertical: 14,
          borderRadius: 16,
        }}
      >
        <Text style={{ color: "white", fontWeight: "800", fontSize: 18 }}>▶ PLAY</Text>
      </TouchableOpacity>
    </View>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Game" component={GameScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
