import { useEffect, useState } from "react";
import { Asset } from "expo-asset";
import * as FileSystem from "expo-file-system";

export function useLocalHtml(assetModule: any) {
  const [uri, setUri] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    async function load() {
      try {
        const asset = Asset.fromModule(assetModule);
        await asset.downloadAsync();

        const targetUri = FileSystem.documentDirectory + "game.html";

        if (asset.localUri) {
          await FileSystem.copyAsync({ from: asset.localUri, to: targetUri });
          if (mounted) setUri(targetUri);
        }
      } catch (err) {
        console.warn("Failed to load local html:", err);
      }
    }

    load();
    return () => { mounted = false; };
  }, [assetModule]);

  return uri;
}
