import React from "react";
import { View, ActivityIndicator, Text, TouchableOpacity } from "react-native";
import { WebView } from "react-native-webview";
import { useLocalHtml } from "./useLocalHtml";

export default function GameScreen({ navigation }: any) {
  const htmlUri = useLocalHtml(require("./game.html"));

  if (!htmlUri) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" />
        <Text style={{ marginTop: 12 }}>Loading game…</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <WebView
        source={{ uri: htmlUri }}
        originWhitelist={["*"]}
        javaScriptEnabled
        domStorageEnabled
        allowsFullscreenVideo
        allowsInlineMediaPlayback
        mediaPlaybackRequiresUserAction={false}
        onMessage={(event) => {
          // Hook for haptics later
          // console.log("Message from game:", event.nativeEvent.data);
        }}
      />

      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={{
          position: "absolute",
          top: 50,
          left: 16,
          paddingHorizontal: 12,
          paddingVertical: 8,
          borderRadius: 12,
          backgroundColor: "rgba(0,0,0,0.55)",
        }}
      >
        <Text style={{ color: "white", fontWeight: "600" }}>◀ Back</Text>
      </TouchableOpacity>
    </View>
  );
}
