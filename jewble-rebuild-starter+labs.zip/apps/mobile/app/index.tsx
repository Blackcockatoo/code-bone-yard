import { useMemo } from 'react';
import { Text, View } from 'react-native';
import { decodeGenome, type Genome } from '@jewble/core';

export default function Home() {
  const traits = useMemo(() => {
    const g: Genome = {
      red60: Array.from({ length: 60 }, () => 1 as any),
      blue60: Array.from({ length: 60 }, () => 2 as any),
      black60: Array.from({ length: 60 }, () => 3 as any),
    };
    return decodeGenome(g);
  }, []);

  return (
    <View style={{ flex: 1, padding: 24, justifyContent: 'center' }}>
      <Text style={{ fontSize: 24, fontWeight: '700', marginBottom: 12 }}>Jewble (Rebuild)</Text>
      <Text style={{ marginBottom: 12 }}>Mobile shell wired to @jewble/core.</Text>
      <Text style={{ fontFamily: 'monospace' }}>{JSON.stringify(traits, null, 2)}</Text>
    </View>
  );
}
