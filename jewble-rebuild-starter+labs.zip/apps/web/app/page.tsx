import Link from 'next/link';
import { decodeGenome, type Genome } from '@jewble/core';

export default function Page() {
  const g: Genome = {
    red60: Array.from({ length: 60 }, () => 1 as any),
    blue60: Array.from({ length: 60 }, () => 2 as any),
    black60: Array.from({ length: 60 }, () => 3 as any),
  };
  const traits = decodeGenome(g);

  return (
    <main style={{ padding: 24 }}>
      <h1>Jewble (Rebuild)</h1>
      <p style={{ opacity: 0.85 }}>
        Web shell for inspecting the core engine. <Link href="/labs">Open Labs</Link>
      </p>
      <pre style={{ marginTop: 16 }}>{JSON.stringify(traits, null, 2)}</pre>
    </main>
  );
}
