export default function Page() {
  return (
    <main style={ height: '100vh', display: 'flex', flexDirection: 'column' }>
      <div style={ padding: 12, borderBottom: '1px solid rgba(255,255,255,0.12)' }>
        <a href="/labs" style={ marginRight: 12 }>← Labs</a>
        <strong>Cellular Automata — Moss60 Lineages</strong>
        <span style={ opacity: 0.7, marginLeft: 10 }>(embedded)</span>
      </div>
      <iframe
        src="/labsrc/cellular-automata.html"
        style={ flex: 1, border: 'none', width: '100%' }
        title="Cellular Automata — Moss60 Lineages"
        sandbox="allow-scripts allow-forms allow-same-origin allow-modals allow-popups allow-downloads"
      />
    </main>
  );
}
