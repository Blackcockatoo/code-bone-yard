export default function Page() {
  return (
    <main style={ height: '100vh', display: 'flex', flexDirection: 'column' }>
      <div style={ padding: 12, borderBottom: '1px solid rgba(255,255,255,0.12)' }>
        <a href="/labs" style={ marginRight: 12 }>← Labs</a>
        <strong>Fibonacci 60 × Lukas 12 — Yantra Tiles</strong>
        <span style={ opacity: 0.7, marginLeft: 10 }>(embedded)</span>
      </div>
      <iframe
        src="/labsrc/lukas12-yantra-tiles.html"
        style={ flex: 1, border: 'none', width: '100%' }
        title="Fibonacci 60 × Lukas 12 — Yantra Tiles"
        sandbox="allow-scripts allow-forms allow-same-origin allow-modals allow-popups allow-downloads"
      />
    </main>
  );
}
