import Link from 'next/link';

const links = [
  { href: '/labs/moss60', title: 'MOSS60 Ultimate', desc: 'Glyph + messaging + QR + storage + oracle sandbox (embedded).' },
  { href: '/labs/automata', title: 'Cellular Automata', desc: '1D CA ring with Moss60 red/blue/black lineage colouring.' },
  { href: '/labs/yantra', title: 'Lukas 12 Yantra Tiles', desc: 'Fibonacci-60 × Lukas-12 breathing tile wall.' },
];

export default function LabsPage() {
  return (
    <main style={{ padding: 24, maxWidth: 980, margin: '0 auto' }}>
      <h1 style={{ fontSize: 32, marginBottom: 8 }}>Labs</h1>
      <p style={{ opacity: 0.85, marginBottom: 20 }}>
        Prototype visual systems stitched into the Jewble/Jeble build.
      </p>

      <div style={{ display: 'grid', gap: 12 }}>
        {links.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            style={{
              display: 'block',
              padding: 16,
              border: '1px solid rgba(255,255,255,0.12)',
              borderRadius: 12,
              textDecoration: 'none',
            }}
          >
            <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>{l.title}</div>
            <div style={{ opacity: 0.8 }}>{l.desc}</div>
          </Link>
        ))}
      </div>
    </main>
  );
}
