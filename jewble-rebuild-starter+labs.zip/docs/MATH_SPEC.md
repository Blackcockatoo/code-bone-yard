# Jewble Math Spec (Template)

This is the living spec. Keep it human-readable and test-driven.

## 1. Genome
- Input: three vault arrays (red60/blue60/black60) of integers 0–6 (base-7 digits).
- Outputs: trait objects, seeds, invariants.

### Definitions
- **Hepta digit**: d ∈ {0..6}
- **Hepta triple**: Z = d0 + 7 d1 + 49 d2

## 2. Vitals
- Tick model: discrete ticks of `tickMs` milliseconds.
- Decay rates and interaction effects must be explicitly stated and tested.

## 3. Elements (if used)
- Define mapping rules clearly (e.g., residues mod 60, tiers, bridge nodes).
- Each derived quantity must list formula + units + intended use.

## 4. Invariants & Seeds
- Define which invariants are stable across time vs. time-evolving.
- Specify seed derivation with collision expectations.

## 5. Test vectors
Add known-good vectors here, then codify them as unit tests.
