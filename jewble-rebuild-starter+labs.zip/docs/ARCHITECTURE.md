# Architecture

## Goals
- Deterministic, testable *math + simulation* in `packages/core` (no UI, no platform APIs).
- Thin UI shells in `apps/*`.
- Every “mystical” feature has a clear spec + tests + user-facing explanation.

## Layers
1. **Core (Pure TypeScript)** — genome decoding, vitals simulation, element-math, seeds, invariants.
2. **UI** — renders state, inputs user intent, shows explanations.
3. **Runtime** — storage, audio, haptics, notifications, sync.

## Determinism contract
- Given the same inputs (genome + time + actions), outputs must match bit-for-bit.
- No `Date.now()` in core logic; time is injected.

## Recommended rule
- If it’s math: it goes in `packages/core` with tests.
- If it’s UX: it goes in `apps/mobile` or `apps/web`.
