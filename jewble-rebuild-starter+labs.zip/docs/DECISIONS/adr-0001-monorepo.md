# ADR-0001: Monorepo with pnpm + Turborepo

## Status
Accepted

## Context
We need shared math/simulation packages used by multiple apps (mobile + web).

## Decision
Use pnpm workspaces + Turborepo for caching and task orchestration.

## Consequences
- Shared code is cleanly versioned and tested.
- CI is faster via caching and isolated tasks.
