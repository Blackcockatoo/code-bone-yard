# Jewble (Rebuild) — Monorepo Starter

This repo is a clean, “do it properly” rebuild scaffold for Jewble / Meta‑Pet:
- **apps/mobile** — Expo + expo-router (React Native)
- **apps/web** — Next.js web shell for dashboards / inspection tools
- **packages/core** — pure deterministic math + simulation engine (genome, vitals, etc.)
- **docs/** — architecture + math spec + ADRs
- **.github/workflows** — CI for lint/typecheck/test/build

## Design principles (non‑negotiable)
1. **Determinism:** core produces identical outputs for identical inputs. No platform APIs in core.
2. **Explainability:** every “mystical” mechanic has a written spec in `docs/MATH_SPEC.md` and unit tests.
3. **Separation:** UI is a thin layer. Domain logic lives in `packages/core`.
4. **Test vectors:** any important formula gets at least 2–3 known-good vectors and regression tests.

## Prerequisites
- Node >= 20
- pnpm 9.x

## Quickstart
```bash
pnpm install
pnpm dev
```

### Run apps
```bash
pnpm --filter @jewble/web dev
pnpm --filter @jewble/mobile dev
```

### Core tests
```bash
pnpm --filter @jewble/core test
```

## Repo layout
```
apps/
  mobile/         # Expo app (UI + platform)
  web/            # Next.js app (UI + dashboards)
packages/
  core/           # deterministic engine (NO Date.now, NO storage, NO audio)
docs/
  ARCHITECTURE.md
  MATH_SPEC.md
  DECISIONS/
```

## What you fill in next
- Replace placeholder `decodeGenome()` logic with the real Jewble math.
- Decide and document the *meaning* of each vital (e.g., hunger “0=full, 100=starving” vs inverse) and make UI match.
- Add the “Elements / 60‑adic / hepta” modules **only if** they have:
  - spec in `docs/MATH_SPEC.md`
  - unit tests + vectors
  - UX explanation screens

## Suggested next steps (high impact)
- Add `packages/core/src/elements/*` once the spec is stable.
- Add `packages/core/src/seed/*` for deterministic seed derivations.
- Add `packages/core/src/invariants/*` so UI can show “this is stable / this evolves”.
- Add `docs/GLOSSARY.md` so terms are consistent across code and UI.

## License
Pick a license (MIT/Apache-2.0/Proprietary) and add it as `LICENSE`.


## Labs

Run the web app and open `/labs` to access embedded visual prototypes (MOSS60 Ultimate, CA lineages, Yantra tiles).
