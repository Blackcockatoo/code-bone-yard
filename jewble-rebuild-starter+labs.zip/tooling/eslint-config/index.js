export default [
  {
    ignores: ['**/dist/**', '**/.next/**', '**/node_modules/**'],
  },
  {
    rules: {
      'no-unused-vars': 'warn'
    },
  },
];
