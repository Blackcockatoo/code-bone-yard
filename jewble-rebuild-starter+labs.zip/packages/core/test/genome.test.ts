import { describe, expect, test } from 'vitest';
import { decodeGenome, type Genome } from '../src/genome';

const mk = (d: number) => Array.from({ length: 60 }, () => d as any);

describe('decodeGenome', () => {
  test('is deterministic', () => {
    const g: Genome = { red60: mk(1), blue60: mk(2), black60: mk(3) };
    expect(decodeGenome(g)).toEqual(decodeGenome(g));
  });

  test('rejects invalid digits', () => {
    const g: any = { red60: mk(1), blue60: mk(2), black60: mk(3) };
    g.red60[0] = 9;
    expect(() => decodeGenome(g)).toThrow();
  });
});
