export interface Vitals {
  hunger: number;  // 0..100 (0=full, 100=starving) OR reverse — decide and document clearly.
  hygiene: number; // 0..100
  mood: number;    // 0..100
  energy: number;  // 0..100
}

export const DEFAULT_VITALS: Vitals = {
  hunger: 30,
  hygiene: 70,
  mood: 60,
  energy: 80,
};

export function clamp(value: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, value));
}

export function avg(v: Vitals): number {
  return (v.hunger + v.hygiene + v.mood + v.energy) / 4;
}

export const DECAY_RATES = {
  hunger: 0.25,
  hygiene: -0.15,
  energy: -0.2,
  mood: 0.05,
} as const;

export type Interaction = 'feed' | 'clean' | 'play' | 'sleep';

export const INTERACTION_EFFECTS: Record<Interaction, Partial<Vitals>> = {
  feed: { hunger: -20, energy: 5, mood: 3 },
  clean: { hygiene: 25, mood: 5 },
  play: { mood: 15, energy: -10, hygiene: -5 },
  sleep: { energy: 30, mood: 5 },
};

export function tick(v: Vitals): Vitals {
  const next = { ...v };
  next.hunger = clamp(next.hunger + DECAY_RATES.hunger);
  next.hygiene = clamp(next.hygiene + DECAY_RATES.hygiene);
  next.energy = clamp(next.energy + DECAY_RATES.energy);
  next.mood = clamp(next.mood + (next.energy > 50 ? DECAY_RATES.mood : -DECAY_RATES.mood));
  return next;
}

export function applyInteraction(v: Vitals, action: Interaction): Vitals {
  const delta = INTERACTION_EFFECTS[action];
  const next = { ...v };
  for (const [k, dv] of Object.entries(delta)) {
    const key = k as keyof Vitals;
    next[key] = clamp(next[key] + (dv ?? 0));
  }
  return next;
}
