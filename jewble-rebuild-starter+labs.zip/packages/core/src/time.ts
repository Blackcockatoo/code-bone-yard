/**
 * Core MUST be deterministic.
 * No Date.now() inside core. Inject time through this interface.
 */
export interface Clock {
  nowMs(): number;
}

export class SystemClock implements Clock {
  nowMs(): number {
    return Date.now();
  }
}
