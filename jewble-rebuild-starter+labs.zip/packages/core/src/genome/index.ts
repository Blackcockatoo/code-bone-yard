export type HeptaDigit = 0 | 1 | 2 | 3 | 4 | 5 | 6;

export interface Genome {
  red60: HeptaDigit[];   // physical
  blue60: HeptaDigit[];  // personality
  black60: HeptaDigit[]; // latent
}

export interface Traits {
  physical: { bodyType: string };
  personality: { temperament: string };
  latent: { evolutionPath: string };
}

export function assertGenome(g: Genome): void {
  const check = (arr: HeptaDigit[], name: string) => {
    if (arr.length !== 60) throw new Error(`${name} must be length 60`);
    for (const d of arr) {
      if (d < 0 || d > 6) throw new Error(`${name} contains invalid digit ${d}`);
    }
  };
  check(g.red60, 'red60');
  check(g.blue60, 'blue60');
  check(g.black60, 'black60');
}

/**
 * Placeholder decoder:
 * Replace with your “real math”, but keep this function PURE + TESTED.
 */
export function decodeGenome(g: Genome): Traits {
  assertGenome(g);

  const sum = (xs: HeptaDigit[]) => xs.reduce((a, b) => a + b, 0);
  const r = sum(g.red60);
  const b = sum(g.blue60);
  const k = sum(g.black60);

  const bodyType = r % 3 === 0 ? 'Angular' : r % 3 === 1 ? 'Round' : 'Spiral';
  const temperament = b % 3 === 0 ? 'Calm' : b % 3 === 1 ? 'Wild' : 'Curious';
  const evolutionPath = k % 3 === 0 ? 'Solar' : k % 3 === 1 ? 'Lunar' : 'Void';

  return {
    physical: { bodyType },
    personality: { temperament },
    latent: { evolutionPath },
  };
}
