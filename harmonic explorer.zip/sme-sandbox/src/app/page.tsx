import { Suspense } from 'react';
import type { Metadata } from 'next';
import SimulationWrapper from '@/components/simulation/SimulationWrapper';

export const metadata: Metadata = {
  title: 'SME Sandbox: Structured Motion Equation Simulator',
  description: 'An interactive simulation of orbital dynamics using Tom\'s Structured Motion Equation, a non-chaotic approach to multi-body systems.',
};

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-950 p-2 md:p-4">
      <Suspense fallback={<div>Loading simulation...</div>}>
        <SimulationWrapper />
      </Suspense>
    </main>
  );
}
