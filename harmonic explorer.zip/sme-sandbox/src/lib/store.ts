import { create } from 'zustand';
import {
  SimulationState,
  Body,
  HarmonicParameters,
  DEFAULT_HARMONIC_PARAMETERS,
  THREE_BODY_SCENARIO,
  SOLAR_SYSTEM_SCENARIO,
  MOLECULAR_SCENARIO,
  updateBodyWithSME
} from './sme-equations';

interface SimulationStore extends SimulationState {
  // Initialize the simulation
  initializeSimulation: (scenario: 'threeBody' | 'solarSystem' | 'molecular' | 'custom') => void;

  // Update simulation parameters
  setHarmonicParameters: (params: Partial<HarmonicParameters>) => void;
  setTimeScale: (scale: number) => void;
  setRunning: (isRunning: boolean) => void;
  toggleRunning: () => void;
  setShowTrails: (show: boolean) => void;
  setShowHarmonicWaves: (show: boolean) => void;
  setDimension: (dimension: '2d' | '3d') => void;

  // Body manipulation
  addBody: (body: Body) => void;
  removeBody: (id: string) => void;
  updateBody: (id: string, updates: Partial<Body>) => void;

  // Simulation advancement
  advanceSimulation: (deltaTime: number) => void;
  resetSimulation: () => void;
}

// Create the Zustand store
const useSimulationStore = create<SimulationStore>((set, get) => ({
  // Initial state
  bodies: [],
  harmonicParameters: DEFAULT_HARMONIC_PARAMETERS,
  timeScale: 1.0,
  running: false,
  showTrails: true,
  showHarmonicWaves: true,
  dimension: '3d',
  time: 0,

  // Initialize the simulation with a predefined scenario
  initializeSimulation: (scenario) => {
    let bodies: Body[] = [];

    switch (scenario) {
      case 'threeBody':
        bodies = [...THREE_BODY_SCENARIO];
        break;
      case 'solarSystem':
        bodies = [...SOLAR_SYSTEM_SCENARIO];
        break;
      case 'molecular':
        bodies = [...MOLECULAR_SCENARIO];
        break;
      case 'custom':
        // Use current bodies or empty array if none
        bodies = get().bodies.length > 0 ? get().bodies : [];
        break;
    }

    set({
      bodies,
      time: 0,
    });
  },

  // Update simulation parameters
  setHarmonicParameters: (params) => {
    set({
      harmonicParameters: {
        ...get().harmonicParameters,
        ...params,
      },
    });
  },

  setTimeScale: (scale) => {
    set({ timeScale: scale });
  },

  setRunning: (isRunning) => {
    set({ running: isRunning });
  },

  toggleRunning: () => {
    set({ running: !get().running });
  },

  setShowTrails: (show) => {
    set({ showTrails: show });
  },

  setShowHarmonicWaves: (show) => {
    set({ showHarmonicWaves: show });
  },

  setDimension: (dimension) => {
    set({ dimension });
  },

  // Body manipulation
  addBody: (body) => {
    set({
      bodies: [...get().bodies, body],
    });
  },

  removeBody: (id) => {
    set({
      bodies: get().bodies.filter(body => body.id !== id),
    });
  },

  updateBody: (id, updates) => {
    set({
      bodies: get().bodies.map(body =>
        body.id === id ? { ...body, ...updates } : body
      ),
    });
  },

  // Simulation advancement
  advanceSimulation: (deltaTime) => {
    const actualDeltaTime = deltaTime * get().timeScale;
    const newTime = get().time + actualDeltaTime;
    const params = get().harmonicParameters;

    // Update body positions and velocities based on SME
    const updatedBodies = get().bodies.map(body =>
      updateBodyWithSME(body, actualDeltaTime, newTime, params)
    );

    set({
      bodies: updatedBodies,
      time: newTime,
    });
  },

  resetSimulation: () => {
    set({ time: 0 });
    get().initializeSimulation('threeBody');
  },
}));

export default useSimulationStore;
