// Structured Motion Equation Mathematical Models

// Type definitions
export interface Body {
  id: string;
  mass: number;
  position: [number, number, number];
  velocity: [number, number, number];
  radius: number;
  color: string;
}

export interface HarmonicParameters {
  amplitudes: [number, number, number, number]; // A, B, C, D coefficients
  frequencies: [number, number, number, number]; // ω₁, ω₂, ω₃, ω₄ frequencies
  damping: number; // γ damping coefficient
  restoring: number; // k harmonic restoring constant
  feedback: number; // ε recursive wave feedback
}

export interface SimulationState {
  bodies: Body[];
  harmonicParameters: HarmonicParameters;
  timeScale: number;
  running: boolean;
  showTrails: boolean;
  showHarmonicWaves: boolean;
  dimension: '2d' | '3d';
  time: number;
}

// Constants
export const DEFAULT_HARMONIC_PARAMETERS: HarmonicParameters = {
  amplitudes: [1, 0.5, 0.25, 0.125],
  frequencies: [1, 2, 3, 5],
  damping: 0.01,
  restoring: 1.0,
  feedback: 0.1,
};

// Utility function to create initial body with structured motion properties
export function createBody(
  id: string,
  mass: number = 1,
  position: [number, number, number] = [0, 0, 0],
  velocity: [number, number, number] = [0, 0, 0],
  radius: number = 1,
  color: string = '#ffffff'
): Body {
  return {
    id,
    mass,
    position,
    velocity,
    radius,
    color,
  };
}

// Structured Motion Equation implementation
// x(t) = A cos(ω₁t) + B cos(ω₂t) + C cos(ω₃t) + D cos(ω₄t)
export function calculateSMEPosition(
  t: number,
  params: HarmonicParameters
): [number, number, number] {
  const { amplitudes, frequencies } = params;

  // Calculate the position based on the quartic harmonic formula
  const x = amplitudes[0] * Math.cos(frequencies[0] * t) +
           amplitudes[1] * Math.cos(frequencies[1] * t) +
           amplitudes[2] * Math.cos(frequencies[2] * t) +
           amplitudes[3] * Math.cos(frequencies[3] * t);

  const y = amplitudes[0] * Math.sin(frequencies[0] * t) +
           amplitudes[1] * Math.sin(frequencies[1] * t) +
           amplitudes[2] * Math.sin(frequencies[2] * t) +
           amplitudes[3] * Math.sin(frequencies[3] * t);

  // z dimension uses different phase to create 3D motion
  const z = amplitudes[0] * Math.sin(frequencies[0] * t + Math.PI/4) +
           amplitudes[1] * Math.sin(frequencies[1] * t + Math.PI/3) +
           amplitudes[2] * Math.sin(frequencies[2] * t + Math.PI/2) +
           amplitudes[3] * Math.sin(frequencies[3] * t + Math.PI);

  return [x, y, z];
}

// The force equation representing SME
// F(t) = m ẍ(t) + γ ẋ(t) + k x(t) + ε cos(φ(t))
export function calculateSMEForce(
  position: [number, number, number],
  velocity: [number, number, number],
  mass: number,
  t: number,
  params: HarmonicParameters
): [number, number, number] {
  const { damping, restoring, feedback } = params;

  // Calculate force components for each dimension
  const calculateForceComponent = (pos: number, vel: number, phase: number): number => {
    // Damping force: -γ ẋ(t)
    const dampingForce = -damping * vel;

    // Restoring force: -k x(t)
    const restoringForce = -restoring * pos;

    // Feedback force: ε cos(φ(t))
    const feedbackForce = feedback * Math.cos(phase);

    // Total force: m ẍ(t) = -γ ẋ(t) - k x(t) + ε cos(φ(t))
    return dampingForce + restoringForce + feedbackForce;
  };

  const phase = t * (Math.sqrt(position[0]**2 + position[1]**2 + position[2]**2) + 1);

  return [
    calculateForceComponent(position[0], velocity[0], phase),
    calculateForceComponent(position[1], velocity[1], phase + Math.PI/3),
    calculateForceComponent(position[2], velocity[2], phase + Math.PI/2),
  ];
}

// Update body position and velocity based on SME
export function updateBodyWithSME(
  body: Body,
  deltaTime: number,
  time: number,
  params: HarmonicParameters
): Body {
  // Calculate force vector
  const force = calculateSMEForce(
    body.position,
    body.velocity,
    body.mass,
    time,
    params
  );

  // Calculate acceleration: F = ma, so a = F/m
  const acceleration: [number, number, number] = [
    force[0] / body.mass,
    force[1] / body.mass,
    force[2] / body.mass,
  ];

  // Update velocity: v = v₀ + a·dt (Euler integration)
  const newVelocity: [number, number, number] = [
    body.velocity[0] + acceleration[0] * deltaTime,
    body.velocity[1] + acceleration[1] * deltaTime,
    body.velocity[2] + acceleration[2] * deltaTime,
  ];

  // Update position: p = p₀ + v·dt (Euler integration)
  const newPosition: [number, number, number] = [
    body.position[0] + newVelocity[0] * deltaTime,
    body.position[1] + newVelocity[1] * deltaTime,
    body.position[2] + newVelocity[2] * deltaTime,
  ];

  // Return updated body
  return {
    ...body,
    position: newPosition,
    velocity: newVelocity,
  };
}

// Calculate gravitational interaction between bodies
export function calculateGravitationalForce(
  body1: Body,
  body2: Body,
  gravitationalConstant: number = 6.67430e-11
): [number, number, number] {
  // Calculate distance vector
  const dx = body2.position[0] - body1.position[0];
  const dy = body2.position[1] - body1.position[1];
  const dz = body2.position[2] - body1.position[2];

  // Calculate squared distance
  const distanceSquared = dx*dx + dy*dy + dz*dz;

  // Avoid division by zero or very small numbers
  if (distanceSquared < 0.0001) {
    return [0, 0, 0];
  }

  // Calculate distance
  const distance = Math.sqrt(distanceSquared);

  // Calculate gravitational force magnitude: F = G * m1 * m2 / r²
  const forceMagnitude = gravitationalConstant * body1.mass * body2.mass / distanceSquared;

  // Calculate force components
  return [
    (forceMagnitude * dx) / distance,
    (forceMagnitude * dy) / distance,
    (forceMagnitude * dz) / distance,
  ];
}

// Predefined scenarios
export const THREE_BODY_SCENARIO: Body[] = [
  createBody('body1', 10, [2, 0, 0], [0, 1, 0], 0.5, '#ff4500'),
  createBody('body2', 10, [-2, 0, 0], [0, -1, 0], 0.5, '#4169e1'),
  createBody('body3', 5, [0, 3, 0], [-1.5, 0, 0], 0.3, '#7cfc00'),
];

export const SOLAR_SYSTEM_SCENARIO: Body[] = [
  createBody('sun', 100, [0, 0, 0], [0, 0, 0], 2, '#ffff00'),
  createBody('mercury', 1, [3, 0, 0], [0, 2.5, 0], 0.2, '#a0a0a0'),
  createBody('venus', 2, [5, 0, 0], [0, 2, 0], 0.3, '#ffa500'),
  createBody('earth', 2, [7, 0, 0], [0, 1.5, 0], 0.3, '#00bfff'),
  createBody('mars', 1.5, [9, 0, 0], [0, 1.2, 0], 0.25, '#ff4500'),
];

export const MOLECULAR_SCENARIO: Body[] = [
  createBody('nucleus', 10, [0, 0, 0], [0, 0, 0], 0.5, '#ffffff'),
  createBody('electron1', 0.1, [2, 0, 0], [0, 2, 0], 0.1, '#00ffff'),
  createBody('electron2', 0.1, [-1, 1.73, 0], [-1.73, -1, 0], 0.1, '#00ffff'),
  createBody('electron3', 0.1, [-1, -1.73, 0], [1.73, -1, 0], 0.1, '#00ffff'),
];
