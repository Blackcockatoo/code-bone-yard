'use client';

import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import {
  PlayCircle,
  PauseCircle,
  RefreshCw,
  Orbit,
  Box,
  Boxes,
  Settings,
  Activity
} from 'lucide-react';
import useSimulationStore from '@/lib/store';
import { createBody } from '@/lib/sme-equations';

// Rest of the component remains the same
export default function ControlPanel() {
  const {
    running,
    toggleRunning,
    resetSimulation,
    initializeSimulation,
    setTimeScale,
    timeScale,
    setShowTrails,
    showTrails,
    setShowHarmonicWaves,
    showHarmonicWaves,
    setDimension,
    dimension,
    setHarmonicParameters,
    harmonicParameters,
    bodies,
    addBody,
    removeBody,
  } = useSimulationStore();

  // Rest of the code...
  const [selectedScenario, setSelectedScenario] = useState<'threeBody' | 'solarSystem' | 'molecular' | 'custom'>('threeBody');

  const handleScenarioChange = (scenario: 'threeBody' | 'solarSystem' | 'molecular' | 'custom') => {
    setSelectedScenario(scenario);
    initializeSimulation(scenario);
  };

  const handleAddRandomBody = () => {
    // Create a random body with harmonically influenced properties
    const id = `body-${bodies.length + 1}`;
    const mass = Math.random() * 5 + 1;
    const radius = Math.sqrt(mass) * 0.2;

    // Create a random color with a bias towards brighter colors
    const r = Math.floor(Math.random() * 128 + 128).toString(16).padStart(2, '0');
    const g = Math.floor(Math.random() * 128 + 128).toString(16).padStart(2, '0');
    const b = Math.floor(Math.random() * 128 + 128).toString(16).padStart(2, '0');
    const color = `#${r}${g}${b}`;

    // Position and velocity based on harmonic parameters
    const angle = Math.random() * Math.PI * 2;
    const distance = Math.random() * 5 + 3;
    const position: [number, number, number] = [
      Math.cos(angle) * distance,
      Math.sin(angle) * distance,
      (Math.random() - 0.5) * distance * 0.5,
    ];

    // Velocity perpendicular to position for orbital motion
    const velocityMagnitude = Math.sqrt(5 / distance) * 1.5;
    const velocity: [number, number, number] = [
      -position[1] * velocityMagnitude / Math.sqrt(position[0] * position[0] + position[1] * position[1]),
      position[0] * velocityMagnitude / Math.sqrt(position[0] * position[0] + position[1] * position[1]),
      (Math.random() - 0.5) * 0.2,
    ];

    const newBody = createBody(id, mass, position, velocity, radius, color);
    addBody(newBody);
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle>SME-Sandbox Control Panel</CardTitle>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="icon"
              onClick={toggleRunning}
              title={running ? "Pause Simulation" : "Start Simulation"}
            >
              {running ? <PauseCircle /> : <PlayCircle />}
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={resetSimulation}
              title="Reset Simulation"
            >
              <RefreshCw />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="scenario">
          <TabsList className="w-full">
            <TabsTrigger value="scenario" className="flex items-center">
              <Orbit className="mr-2 h-4 w-4" /> Scenario
            </TabsTrigger>
            <TabsTrigger value="parameters" className="flex items-center">
              <Activity className="mr-2 h-4 w-4" /> Harmonics
            </TabsTrigger>
            <TabsTrigger value="display" className="flex items-center">
              <Settings className="mr-2 h-4 w-4" /> Display
            </TabsTrigger>
          </TabsList>

          {/* Scenario Tab */}
          <TabsContent value="scenario" className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedScenario === 'threeBody' ? "default" : "outline"}
                onClick={() => handleScenarioChange('threeBody')}
              >
                Three-Body
              </Button>
              <Button
                variant={selectedScenario === 'solarSystem' ? "default" : "outline"}
                onClick={() => handleScenarioChange('solarSystem')}
              >
                Solar System
              </Button>
              <Button
                variant={selectedScenario === 'molecular' ? "default" : "outline"}
                onClick={() => handleScenarioChange('molecular')}
              >
                Molecular
              </Button>
              <Button
                variant={selectedScenario === 'custom' ? "default" : "outline"}
                onClick={() => handleScenarioChange('custom')}
              >
                Custom
              </Button>
            </div>

            {selectedScenario === 'custom' && (
              <div className="mt-4">
                <Button onClick={handleAddRandomBody}>Add Random Body</Button>
                {bodies.length > 0 && (
                  <div className="mt-2">
                    <h3 className="text-sm font-medium mb-2">Current Bodies:</h3>
                    <div className="max-h-28 overflow-y-auto">
                      {bodies.map((body) => (
                        <div key={body.id} className="flex justify-between items-center py-1">
                          <div className="flex items-center">
                            <div
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ backgroundColor: body.color }}
                            />
                            <span className="text-sm">{body.id} (Mass: {body.mass.toFixed(1)})</span>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeBody(body.id)}
                            className="h-6 px-2"
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          {/* Harmonics Tab */}
          <TabsContent value="parameters" className="space-y-4">
            {/* Time Scale Control */}
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Time Scale: {timeScale.toFixed(2)}x</span>
              </div>
              <Slider
                value={[timeScale]}
                min={0.1}
                max={5}
                step={0.1}
                onValueChange={(value) => setTimeScale(value[0])}
              />
            </div>

            <Separator />

            {/* Amplitude Controls */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Amplitude Coefficients (A, B, C, D)</h3>
              {harmonicParameters.amplitudes.map((amplitude, index) => (
                <div key={`amplitude-${index}`} className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-xs">
                      Amplitude {index + 1}: {amplitude.toFixed(2)}
                    </span>
                  </div>
                  <Slider
                    value={[amplitude]}
                    min={0}
                    max={2}
                    step={0.01}
                    onValueChange={(value) => {
                      const newAmplitudes = [...harmonicParameters.amplitudes];
                      newAmplitudes[index] = value[0];
                      setHarmonicParameters({ amplitudes: newAmplitudes as [number, number, number, number] });
                    }}
                  />
                </div>
              ))}
            </div>

            <Separator />

            {/* Frequency Controls */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Frequency Coefficients (ω₁, ω₂, ω₃, ω₄)</h3>
              {harmonicParameters.frequencies.map((frequency, index) => (
                <div key={`frequency-${index}`} className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-xs">
                      Frequency {index + 1}: {frequency.toFixed(2)}
                    </span>
                  </div>
                  <Slider
                    value={[frequency]}
                    min={0.1}
                    max={10}
                    step={0.1}
                    onValueChange={(value) => {
                      const newFrequencies = [...harmonicParameters.frequencies];
                      newFrequencies[index] = value[0];
                      setHarmonicParameters({ frequencies: newFrequencies as [number, number, number, number] });
                    }}
                  />
                </div>
              ))}
            </div>

            <Separator />

            {/* Other Parameters */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Dynamic Parameters</h3>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-xs">
                    Damping (γ): {harmonicParameters.damping.toFixed(3)}
                  </span>
                </div>
                <Slider
                  value={[harmonicParameters.damping]}
                  min={0}
                  max={0.1}
                  step={0.001}
                  onValueChange={(value) => setHarmonicParameters({ damping: value[0] })}
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-xs">
                    Restoring (k): {harmonicParameters.restoring.toFixed(2)}
                  </span>
                </div>
                <Slider
                  value={[harmonicParameters.restoring]}
                  min={0.1}
                  max={5}
                  step={0.1}
                  onValueChange={(value) => setHarmonicParameters({ restoring: value[0] })}
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-xs">
                    Feedback (ε): {harmonicParameters.feedback.toFixed(2)}
                  </span>
                </div>
                <Slider
                  value={[harmonicParameters.feedback]}
                  min={0}
                  max={1}
                  step={0.01}
                  onValueChange={(value) => setHarmonicParameters({ feedback: value[0] })}
                />
              </div>
            </div>
          </TabsContent>

          {/* Display Tab */}
          <TabsContent value="display">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Show Harmonic Waves</span>
                <Switch
                  checked={showHarmonicWaves}
                  onCheckedChange={setShowHarmonicWaves}
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Show Trails</span>
                <Switch
                  checked={showTrails}
                  onCheckedChange={setShowTrails}
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Dimension</span>
                <div className="flex space-x-2">
                  <Button
                    variant={dimension === '2d' ? "default" : "outline"}
                    size="sm"
                    onClick={() => setDimension('2d')}
                    className="h-8"
                  >
                    <Box className="h-4 w-4 mr-1" /> 2D
                  </Button>
                  <Button
                    variant={dimension === '3d' ? "default" : "outline"}
                    size="sm"
                    onClick={() => setDimension('3d')}
                    className="h-8"
                  >
                    <Boxes className="h-4 w-4 mr-1" /> 3D
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
