'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Info, BookOpen, Code2, FileText } from 'lucide-react';

export default function InfoPanel() {
  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <Info className="h-5 w-5 mr-2" />
            SME Information
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview">
          <TabsList className="w-full">
            <TabsTrigger value="overview" className="flex items-center">
              <BookOpen className="mr-2 h-4 w-4" /> Overview
            </TabsTrigger>
            <TabsTrigger value="equations" className="flex items-center">
              <FileText className="mr-2 h-4 w-4" /> Equations
            </TabsTrigger>
            <TabsTrigger value="details" className="flex items-center">
              <Code2 className="mr-2 h-4 w-4" /> Technical Details
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-2 text-sm">
            <h3 className="font-semibold text-md">Structured Motion Equation Sandbox</h3>
            <p>
              Welcome to the Structured Motion Equation (SME) Sandbox. This simulation
              demonstrates a non-chaotic alternative to traditional orbital dynamics by using
              a quartic harmonic model instead of purely Newtonian gravitation.
            </p>
            <p>
              Unlike conventional N-body simulations that exhibit chaotic behavior, SME
              produces stable, predictable motion patterns through resonant harmonic interactions.
            </p>
            <p>
              The fundamental idea is that orbital motion can be expressed as a sum of harmonic
              oscillations with resonant frequencies, creating a structured wave pattern that
              maintains coherence over time.
            </p>
            <h4 className="font-semibold mt-2">Key Concepts:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                <span className="font-medium">Non-Chaotic Motion:</span> SME replaces chaotic divergence
                with stable, recursive patterns.
              </li>
              <li>
                <span className="font-medium">Harmonic Resonance:</span> Bodies follow wave-like trajectories
                governed by resonant frequencies.
              </li>
              <li>
                <span className="font-medium">Recursive Stability:</span> The system applies corrective
                feedback to maintain coherent motion.
              </li>
            </ul>
          </TabsContent>

          {/* Equations Tab */}
          <TabsContent value="equations" className="space-y-3 text-sm">
            <div>
              <h3 className="font-semibold">Core SME Formula</h3>
              <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded my-2 overflow-x-auto">
                <code>x(t) = A·cos(ω₁t) + B·cos(ω₂t) + C·cos(ω₃t) + D·cos(ω₄t)</code>
              </div>
              <p>
                The position of a body is determined by a quartic harmonic equation where:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-1">
                <li>A, B, C, D are amplitude coefficients linked to mass and initial conditions</li>
                <li>ω₁, ω₂, ω₃, ω₄ are harmonic frequencies derived from system properties</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold">Force Equation</h3>
              <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded my-2 overflow-x-auto">
                <code>F(t) = m·ẍ(t) + γ·ẋ(t) + k·x(t) + ε·cos(φ(t))</code>
              </div>
              <p>
                The dynamic forces in the system include:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-1">
                <li>m: mass parameter</li>
                <li>γ: damping coefficient</li>
                <li>k: harmonic restoring constant</li>
                <li>ε: recursive wave feedback coefficient</li>
                <li>φ(t): phase function dependent on position and time</li>
              </ul>
            </div>
          </TabsContent>

          {/* Technical Details Tab */}
          <TabsContent value="details" className="space-y-2 text-sm">
            <h3 className="font-semibold">Simulation Architecture</h3>
            <p>
              This implementation uses a hybrid symplectic integrator that preserves energy
              in the system while maintaining computational stability.
            </p>

            <h4 className="font-semibold mt-2">Key Components:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                <span className="font-medium">Harmonic Integrator:</span> Updates positions
                using the quartic SME formula.
              </li>
              <li>
                <span className="font-medium">Wave Feedback System:</span> Applies corrective
                forces to maintain coherent trajectories.
              </li>
              <li>
                <span className="font-medium">Resonance Detection:</span> Identifies and maintains
                stable frequency relationships.
              </li>
            </ul>

            <h4 className="font-semibold mt-2">Applications:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                <span className="font-medium">Astrophysics:</span> Modeling orbital systems with
                long-term stability.
              </li>
              <li>
                <span className="font-medium">Molecular Dynamics:</span> Simulating electron orbits
                and resonant structures.
              </li>
              <li>
                <span className="font-medium">Fractal Systems:</span> Generating self-similar
                patterns through recursive motion.
              </li>
            </ul>

            <p className="mt-2 italic">
              This research introduces a paradigm shift in dynamical systems, replacing chaos
              theory with structured harmonic interactions that maintain coherence across scales.
            </p>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
