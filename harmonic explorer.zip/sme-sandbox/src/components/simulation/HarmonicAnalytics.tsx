'use client';

import { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Activity, BarChart3, Maximize } from 'lucide-react';
import useSimulationStore from '@/lib/store';

// Simple canvas-based line chart component
const LineChart = ({
  data,
  label,
  color = '#3b82f6',
  height = 100,
  gridColor = '#e5e7eb',
  backgroundColor = 'transparent'
}: {
  data: number[];
  label: string;
  color?: string;
  height?: number;
  gridColor?: string;
  backgroundColor?: string;
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Get the container width and set canvas dimensions
    const container = canvas.parentElement;
    if (!container) return;

    canvas.width = container.clientWidth;
    canvas.height = height;

    const width = canvas.width;
    const h = canvas.height;

    // Clear the canvas
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, width, h);

    // Draw grid lines
    ctx.strokeStyle = gridColor;
    ctx.lineWidth = 0.5;

    // Horizontal grid lines
    for (let i = 0; i <= 4; i++) {
      const y = i * (h / 4);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Vertical grid lines
    for (let i = 0; i <= 5; i++) {
      const x = i * (width / 5);
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }

    // No data to plot
    if (data.length === 0) return;

    // Calculate min and max for scaling
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1; // Avoid division by zero

    // Draw the line
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();

    // Move to the first point
    const x0 = 0;
    const y0 = h - ((data[0] - min) / range) * (h * 0.8) - (h * 0.1);
    ctx.moveTo(x0, y0);

    // Draw lines to each subsequent point
    for (let i = 1; i < data.length; i++) {
      const x = (i / (data.length - 1)) * width;
      const y = h - ((data[i] - min) / range) * (h * 0.8) - (h * 0.1);
      ctx.lineTo(x, y);
    }

    ctx.stroke();

    // Add label
    ctx.fillStyle = color;
    ctx.font = '10px sans-serif';
    ctx.fillText(label, 5, 15);

    // Add current value
    const currentValue = data[data.length - 1].toFixed(2);
    ctx.fillText(`Current: ${currentValue}`, width - 80, 15);

  }, [data, color, height, gridColor, backgroundColor, label]);

  return (
    <div className="w-full">
      <canvas ref={canvasRef} />
    </div>
  );
};

// Main harmonic analytics component
export default function HarmonicAnalytics() {
  const { bodies, time, harmonicParameters } = useSimulationStore();

  // Calculate energy data for the first body (if exists)
  const energyData = useRef<number[]>(Array(100).fill(0));
  const resonanceData = useRef<number[]>(Array(100).fill(0));
  const positionXData = useRef<number[]>(Array(100).fill(0));
  const positionYData = useRef<number[]>(Array(100).fill(0));

  useEffect(() => {
    if (bodies.length === 0) return;

    // Get the first body for simplicity
    const body = bodies[0];

    // Calculate kinetic energy: 0.5 * m * v^2
    const velocity = Math.sqrt(
      body.velocity[0] * body.velocity[0] +
      body.velocity[1] * body.velocity[1] +
      body.velocity[2] * body.velocity[2]
    );
    const kineticEnergy = 0.5 * body.mass * velocity * velocity;

    // Calculate potential energy (approximate): G * m1 * m2 / r
    // Using position as a proxy for distance from center
    const distance = Math.sqrt(
      body.position[0] * body.position[0] +
      body.position[1] * body.position[1] +
      body.position[2] * body.position[2]
    );

    const potentialEnergy = distance > 0 ? (6.67430e-11 * body.mass * 10) / distance : 0;

    // Total energy
    const totalEnergy = kineticEnergy + potentialEnergy;

    // Update energy data array
    energyData.current = [...energyData.current.slice(1), totalEnergy];

    // Calculate resonance metric (simple approximation)
    // Using the relationship between position and harmonics
    const positionMagnitude = Math.sqrt(
      body.position[0] * body.position[0] +
      body.position[1] * body.position[1]
    );

    const expectedPosition =
      harmonicParameters.amplitudes[0] * Math.cos(harmonicParameters.frequencies[0] * time) +
      harmonicParameters.amplitudes[1] * Math.cos(harmonicParameters.frequencies[1] * time);

    const resonanceFactor = Math.abs(positionMagnitude - Math.abs(expectedPosition));
    resonanceData.current = [...resonanceData.current.slice(1), resonanceFactor];

    // Update position data
    positionXData.current = [...positionXData.current.slice(1), body.position[0]];
    positionYData.current = [...positionYData.current.slice(1), body.position[1]];

  }, [bodies, time, harmonicParameters]);

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            Harmonic Analytics
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="position">
          <TabsList className="w-full">
            <TabsTrigger value="position" className="flex items-center">
              <Maximize className="mr-2 h-4 w-4" /> Position
            </TabsTrigger>
            <TabsTrigger value="energy" className="flex items-center">
              <BarChart3 className="mr-2 h-4 w-4" /> Energy
            </TabsTrigger>
            <TabsTrigger value="resonance" className="flex items-center">
              <Activity className="mr-2 h-4 w-4" /> Resonance
            </TabsTrigger>
          </TabsList>

          {/* Position Analysis */}
          <TabsContent value="position">
            <div className="space-y-1">
              <LineChart
                data={positionXData.current}
                label="X Position"
                color="#2563eb"
                height={85}
              />
              <LineChart
                data={positionYData.current}
                label="Y Position"
                color="#16a34a"
                height={85}
              />
            </div>
          </TabsContent>

          {/* Energy Analysis */}
          <TabsContent value="energy">
            <LineChart
              data={energyData.current}
              label="System Energy"
              color="#f59e0b"
              height={180}
            />
          </TabsContent>

          {/* Resonance Analysis */}
          <TabsContent value="resonance">
            <LineChart
              data={resonanceData.current}
              label="Harmonic Resonance"
              color="#8b5cf6"
              height={180}
            />
            <div className="text-xs mt-2 text-slate-500">
              <p>
                Lower values indicate stronger harmonic resonance between the body's actual position
                and the predicted position from the quartic SME formula.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
