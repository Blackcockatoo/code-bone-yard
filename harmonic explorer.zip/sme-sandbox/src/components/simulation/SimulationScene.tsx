'use client';

import { useRef, useEffect, Suspense, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Environment, Trail, PerspectiveCamera, Line } from '@react-three/drei';
import { EffectComposer, Bloom } from '@react-three/postprocessing';
import useSimulationStore from '@/lib/store';
import { Body } from '@/lib/sme-equations';
import * as THREE from 'three';

// Error boundary component
const ErrorBoundary = ({ children }: { children: React.ReactNode }) => {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    const errorHandler = (error: ErrorEvent) => {
      console.error('Error caught by boundary:', error);
      setHasError(true);
    };

    window.addEventListener('error', errorHandler);
    return () => window.removeEventListener('error', errorHandler);
  }, []);

  if (hasError) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-black/10 text-center p-4">
        <div>
          <h3 className="text-lg font-bold mb-2">Simulation Error</h3>
          <p>There was an error rendering the 3D simulation.</p>
          <p className="text-sm mt-2">This may be due to WebGL compatibility issues in your browser.</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

// Single celestial body component
const CelestialBody = ({ body, showTrail }: { body: Body; showTrail: boolean }) => {
  const bodyRef = useRef<THREE.Mesh>(null);

  useEffect(() => {
    if (bodyRef.current) {
      bodyRef.current.position.set(body.position[0], body.position[1], body.position[2]);
    }
  }, [body.position]);

  useFrame(() => {
    if (bodyRef.current) {
      bodyRef.current.position.set(body.position[0], body.position[1], body.position[2]);
    }
  });

  return (
    <>
      {showTrail ? (
        <Trail
          width={1}
          length={20}
          color={body.color}
          attenuation={(t) => (1 - t)}
        >
          <mesh ref={bodyRef}>
            <sphereGeometry args={[body.radius, 32, 32]} />
            <meshStandardMaterial
              color={body.color}
              emissive={body.color}
              emissiveIntensity={0.5}
              toneMapped={false}
            />
          </mesh>
        </Trail>
      ) : (
        <mesh ref={bodyRef}>
          <sphereGeometry args={[body.radius, 32, 32]} />
          <meshStandardMaterial
            color={body.color}
            emissive={body.color}
            emissiveIntensity={0.5}
            toneMapped={false}
          />
        </mesh>
      )}
    </>
  );
};

// Wave visualization for harmonic patterns
const HarmonicWaves = ({ time, showWaves }: { time: number; showWaves: boolean }) => {
  const harmonicParams = useSimulationStore(state => state.harmonicParameters);

  // Generate points for the wave visualization
  const points = useMemo(() => {
    const wavePoints = [];

    for (let i = 0; i < 100; i++) {
      const t = time + i * 0.1;
      const x = harmonicParams.amplitudes[0] * Math.cos(harmonicParams.frequencies[0] * t);
      const y = harmonicParams.amplitudes[0] * Math.sin(harmonicParams.frequencies[0] * t);
      const z = 0;
      wavePoints.push(new THREE.Vector3(x, y, z));
    }

    return wavePoints;
  }, [time, harmonicParams]);

  // Don't render anything if waves are disabled
  if (!showWaves) return null;

  return (
    <Line
      points={points}
      color="#88ccff"
      lineWidth={2}
      transparent
      opacity={0.6}
    />
  );
};

// Animation controller component
const AnimationController = () => {
  const { running, advanceSimulation, time, bodies, showHarmonicWaves } = useSimulationStore();
  const showTrails = useSimulationStore(state => state.showTrails);

  useFrame((_, delta) => {
    if (running) {
      advanceSimulation(delta);
    }
  });

  return (
    <>
      {bodies.map((body) => (
        <CelestialBody
          key={body.id}
          body={body}
          showTrail={showTrails}
        />
      ))}
      <HarmonicWaves time={time} showWaves={showHarmonicWaves} />
    </>
  );
};

// Fallback component
const Fallback = () => (
  <div className="w-full h-full flex items-center justify-center bg-slate-100 dark:bg-slate-900">
    <div className="text-center">
      <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" />
      <p className="mt-2">Loading 3D simulation...</p>
    </div>
  </div>
);

// Scene content
const SceneContent = () => {
  const dimension = useSimulationStore(state => state.dimension);

  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 0, 20]} />
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={1} castShadow />

      {/* Grid helper for orientation */}
      <gridHelper
        args={[20, 20, '#444444', '#222222']}
        position={[0, -5, 0]}
        visible={dimension === '3d'}
      />

      {/* 3D controls */}
      <OrbitControls
        enablePan={true}
        enableZoom={true}
        enableRotate={dimension === '3d'}
        target={[0, 0, 0]}
      />

      <AnimationController />

      {/* Post-processing effects */}
      <EffectComposer>
        <Bloom
          intensity={1.5}
          luminanceThreshold={0.1}
          luminanceSmoothing={0.9}
        />
      </EffectComposer>

      <Environment preset="night" />
    </>
  );
};

// Main simulation scene component
export default function SimulationScene() {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  // Check for WebGL support
  const hasWebGL = () => {
    try {
      const canvas = document.createElement('canvas');
      return !!(window.WebGLRenderingContext &&
        (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
    } catch (e) {
      return false;
    }
  };

  if (!isClient) {
    return <Fallback />;
  }

  if (isClient && !hasWebGL()) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-slate-100 dark:bg-slate-900">
        <div className="text-center p-4">
          <h3 className="text-lg font-bold mb-2">WebGL Not Supported</h3>
          <p>Your browser or device does not support WebGL, which is required for this 3D simulation.</p>
          <p className="text-sm mt-2">Try using a modern browser like Chrome, Firefox, or Edge.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full">
      <ErrorBoundary>
        <Suspense fallback={<Fallback />}>
          <Canvas shadows>
            <SceneContent />
          </Canvas>
        </Suspense>
      </ErrorBoundary>
    </div>
  );
}
