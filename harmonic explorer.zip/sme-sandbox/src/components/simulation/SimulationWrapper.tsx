'use client';

import { useEffect } from 'react';
import { Card } from '@/components/ui/card';
import SimulationScene from './SimulationScene';
import ControlPanel from './ControlPanel';
import InfoPanel from './InfoPanel';
import HarmonicAnalytics from './HarmonicAnalytics';
import useSimulationStore from '@/lib/store';

export default function SimulationWrapper() {
  const { initializeSimulation } = useSimulationStore();

  useEffect(() => {
    // Initialize the simulation with the three-body scenario on first render
    console.log('Initializing simulation with threeBody scenario');
    initializeSimulation('threeBody');
  }, [initializeSimulation]);

  console.log('Rendering SimulationWrapper');

  return (
    <div className="w-full max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">
        Structured Motion Equation Sandbox
      </h1>
      <p className="text-center mb-6 max-w-3xl mx-auto text-slate-600 dark:text-slate-400">
        Explore orbital dynamics through a non-chaotic, harmonic framework using the quartic SME formula.
        This interactive simulation demonstrates stable multi-body systems governed by wave-like patterns.
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main simulation display */}
        <div className="lg:col-span-2">
          <Card className="w-full h-[500px] overflow-hidden">
            <SimulationScene />
          </Card>
        </div>

        {/* Control panel */}
        <div className="lg:col-span-1">
          <ControlPanel />
        </div>

        {/* Info panel */}
        <div className="lg:col-span-2">
          <InfoPanel />
        </div>

        {/* Analytics panel */}
        <div className="lg:col-span-1">
          <HarmonicAnalytics />
        </div>
      </div>

      <footer className="mt-8 text-center text-sm text-slate-500 dark:text-slate-400">
        <p>
          Structured Motion Equation Sandbox &copy; {new Date().getFullYear()}
        </p>
        <p className="mt-1">
          A non-chaotic paradigm for orbital dynamics based on Tom's Structured Motion Equation
        </p>
      </footer>
    </div>
  );
}
