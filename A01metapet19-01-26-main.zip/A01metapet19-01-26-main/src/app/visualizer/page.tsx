'use client';

import MetaPetVisualizer from '@/components/MetaPetVisualizer';

const VisualizerPage = () => {
  return <MetaPetVisualizer />;
};

export default VisualizerPage;
